<div class="element-box  onboarding-content">
                    <h4 class="onboarding-title">
                    Save time, money and energy and eliminate paperwork
                  </h4>
                  
                    <ul class="features-list">
                    <li>Save time, money and energy, and eliminate paperwork</li>
                        <li>Simplify audit preparation</li>
                        <li>Even small donations are not lost</li>
                        <li>Keep everything organized</li>
                        <li>Get one receipt for all donations</li>
                        <li>Donate via our website</li>
                        <li>Monthly statements</li>
                        <li>Review the daily status of your account any time</li>
                        <li>Low cost --- great value</li>
                        <li>Keep your funds and information secure</li>
                        <li>Ensure that your funds are deposited into the proper account </li>
                        <li>OJC’s operations are transparent and carefully monitored </li>
                        <li>Conforms to all tax regulations</li>
                        <li>Gives you flexibility at year’s end</li>
                        <li>Get a deduction even when donation is anonymous</li>
                      </ul>
                    </div>