<div class="content-w">
  <div class="content-box">
    <div class="row">
      <div class="col-lg-12">
        <div style="max-height: 50px;" class="element-wrapper">
          <h6 class="element-header">
View All Charties</h6>
        </div>
        <div class="text__descriptyion_wrap mt-2">
          <p> </p>
        </div>
        <div class="element-wrapper">
          <div class="element-box">

            <table id="editableTable" class="table table-editable table-striped table-lightfont" style="cursor: pointer;">
              <thead>
                <tr>
                  <th>Charity Name</th>
                  <th>Period</th>
                  <th>Summary</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td tabindex="1">Tiger Nixon</td> 
                  <td tabindex="1">2011/04/25</td>
                  <td tabindex="1">$320,800</td>
                </tr>
              </tbody>
            </table>
            <input style="position: absolute; display: none;">
          </div>
        </div>
      </div>
    </div>
    <br>
    <div class="row">
      <div class="col-sm-12">
      </div>
    </div>
  </div>
</div>