<div class="content-w order__books__wraper">
    <div class="content-box">
        <div class="element-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div style="max-height: 50px;" class="element-wrapper">
                        <h6 class="element-header"> CHANGE PASSWORD</h6>
                    </div>
                </div>
            </div>
            <br>
            <div class="element-box">
                <br>
                <div class="row" <form="" action="/account/ChangePassword" method="post" novalidate="novalidate">
                    <input name="__RequestVerificationToken" type="hidden" value="WYhJC36Bz6C4bCDP9ETPoNBKCTm2KIFfkeZagKor4s9pxbwb0lDvQMQbYJiE-8X4k1-e5nyAE_42JbOuN7QxEpMf8mDZK3gyfkd6y8JMc7ysNm0eMmiYUTvy7Y2ue93WgVFafueRVBpxBNbWCjd5pA2">
                    <div class="col-md-6">
                        <label> Old Password</label>
                        <input autocomplete="off" class="form-control" data-val="true" data-val-required="Old Password is required" id="OldPassword"
                            name="OldPassword" type="text" value="">
                        <span class="required field-validation-valid" data-valmsg-for="OldPassword" data-valmsg-replace="true"></span>
                    </div>



                    <div class="col-md-6">
                        <label> New Password</label>
                        <input autocomplete="off" class="form-control" data-val="true" data-val-required="New Password is required" id="NewPassword"
                            name="NewPassword" type="password" value="">
                        <span class="required field-validation-valid" data-valmsg-for="NewPassword" data-valmsg-replace="true"></span>

                    </div>

                </div>
                <div class="clear"></div>
                <input type="submit" data-confirm="You're about to update your password. Are you sure you want to continue?" name="" class="btn btn-primary"
                    value="Change Your Password" style="margin: 10px 0px">
            </div>
        </div>
    </div>








    <!--------------------
              START - Chat Popup Box
              -------------------->
    <!--------------------
              END - Chat Popup Box
              -------------------->
</div>