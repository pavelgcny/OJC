<li class="sub-header">
            <span>General</span>
          </li>
          <li class="selected">
            <a href="index.php">
              <div class="icon-w">
                <div class="os-icon os-icon-layout"></div>
              </div>
              <span>My OJC Dashboard</span>
            </a>
          </li>

          <li class="sub-header">
            <span>Donations</span>
          </li>

          <li class="">
            <a href="donateNow.php">
              <div class="icon-w">
                <div class="os-icon os-icon-coins-4"></div>
              </div>
              <span>Donate Now</span>
            </a>
          </li>
          <li class="">
            <a href="scheduleDonations.php">
              <div class="icon-w">
                <div class="os-icon os-icon-calendar-time"></div>
              </div>
              <span>Schedule Donations</span>
            </a>
          </li>
          <li class="">
            <a href="recurringpayment.php">
              <div class="icon-w">
                <div class="os-icon os-icon-calendar-time"></div>
              </div>
              <span>Recurring Payment</span>
            </a>
          </li>
          
          <li class="">
            <a href="statements.php">
              <div class="icon-w">
                <div class="os-icon os-icon-newspaper"></div>
              </div>
              <span>Statements</span>
            </a>
          </li>
          <li class="sub-header">
            <span>Charties</span>
          </li>
          <li class="">
            <a href="viewAllCharties.php">
              <div class="icon-w">
                <div class="os-icon os-icon-bar-chart-up"></div>
              </div>
              <span>View All Charties</span>
            </a>
          </li>
          <li class="">
            <a href="addNewCharties.php">
              <div class="icon-w">
                <div class="os-icon os-icon-bar-chart-stats-up"></div>
              </div>
              <span>Add New Charity</span>
            </a>
          </li>
          <li class="sub-header">
            <span>Transfer to OJC</span>
          </li>
          <li class="">
            <a href="transferNow.php">
              <div class="icon-w">
                <div class="os-icon os-icon-mail-18"></div>
              </div>
              <span>Transfer Now</span>
            </a>
          </li>
          <li class="">
            <a href="scheduleTransfers.php">
              <div class="icon-w">
                <div class="os-icon os-icon-mail-18"></div>
              </div>
              <span>Schedule Transfers</span>
            </a>
          </li>
          <li class="sub-header">
            <span>Cash Vouchers</span>
          </li>
          <li class="">
            <a href="orderNow.php">
              <div class="icon-w">
                <div class="os-icon os-icon-pencil-2"></div>
              </div>
              <span>Order Books</span>
            </a>
          </li>
          <li class="">
            <a href="scheduleBooks.php">
              <div class="icon-w">
                <div class="os-icon os-icon-tasks-checked"></div>
              </div>
              <span>Schedule Books</span>
            </a>
          </li>